pref("extensions.{1280606b-2510-4fe0-97ef-9b5a22eafe80}.description", "chrome://console2/locale/console2.properties");
pref("extensions.console2.max-errors", 1000);
pref("devtools.errorconsole.enabled", true);
