pref("extensions.consolefilter.categories", false);
